import sys

print('Hello from Python!')

sys.stdout.flush()